from quask.datasets import create_gaussian_mixtures
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
import numpy as np
import matplotlib.pyplot as plt


def create_kernel_accuracy_map(K):
    accuracy_map = []
    for i_D, D in enumerate(range(2, 20)):
        accuracy_map.append([])
        random_W = np.random.normal(size=(K, D))
        def random_kernel(X1, X2):
            XX1 = X1.dot(random_W.T)
            XX2 = X2.dot(random_W.T)
            return XX1.dot(XX2.T)

        for i_noise, noise in enumerate(range(0, 11)):
            noise = noise / 10
            X_train, y_train = create_gaussian_mixtures(D, noise, 100)
            X_test, y_test = create_gaussian_mixtures(D, noise, 100)
            accuracy_map[-1].append(0.0)
            for tentative in range(10):
                clf = SVC(kernel=random_kernel)
                clf.fit(X_train, y_train)
                acc = np.average(y_test == clf.predict(X_test), axis=0)
                if acc > accuracy_map[-1][-1]:
                    accuracy_map[-1][-1] = acc

        print(i_D)
        print(accuracy_map[-1])

    plt.clf()
    plt.imshow(accuracy_map, vmin=0.0, vmax=1.0, cmap='seismic')
    plt.colorbar()
    plt.savefig(f'kernel_acc_map_{K}.png')
    plt.clf()


def create_mpl_accuracy_map(K):
    accuracy_map = []
    for i_D, D in enumerate(range(2, 20)):
        accuracy_map.append([])

        for i_noise, noise in enumerate(range(0, 11)):
            noise = noise / 10
            X_train, y_train = create_gaussian_mixtures(D, noise, 100)
            X_test, y_test = create_gaussian_mixtures(D, noise, 100)
            accuracy_map[-1].append(0.0)
            for tentative in range(10):
                clf = MLPClassifier(solver='sgd', max_iter=1000, learning_rate_init=0.01, alpha=1e-5, hidden_layer_sizes=(K,), random_state=np.random.randint(0, 10000))
                clf.fit(X_train, y_train)
                acc = np.average(y_test == clf.predict(X_test), axis=0)
                if acc > accuracy_map[-1][-1]:
                    accuracy_map[-1][-1] = acc

        print(i_D)
        print(accuracy_map[-1])

    plt.clf()
    plt.imshow(accuracy_map, vmin=0.0, vmax=1.0, cmap='seismic')
    plt.colorbar()
    plt.savefig(f'mpl_acc_map_{K}.png')
    plt.clf()

create_kernel_accuracy_map(10)
create_kernel_accuracy_map(50)
create_mpl_accuracy_map(10)
create_mpl_accuracy_map(50)
